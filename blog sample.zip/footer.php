</body>
<div class="w3-container w3-teal">
<p>All rights reserved | <?php echo date("Y");?></p>
</div>